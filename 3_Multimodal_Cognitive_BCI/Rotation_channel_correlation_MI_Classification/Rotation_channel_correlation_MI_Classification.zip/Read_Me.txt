<A channel correlation method for motor imagery classification using rotation matrix>

* Programming Language: MATLAB
* Contact: Y.J. Park (shoutme1@korea.ac.kr)
* Function: First, this code extracts the discrimitive frequency band/time segment using STFT method. Then, computes the channel correlation after passing the STFT band.
	    This algorithm uses the channel correlation as a feature, and uses the rotation matrix which can change the channel correlation.
            Suitable rotation matrix can improve the classification accuracy.